<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>paint</name>
    <message>
        <location filename="../paint.ui" line="14"/>
        <source>Quad Tree (Dynamic Labels)</source>
        <translation>Дерево квадрантов (Динамические метки)</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="42"/>
        <source>Menu</source>
        <translation>Меню</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="48"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="61"/>
        <source>Load points from file...</source>
        <translation>Загрузить точки из файла...</translation>
    </message>
</context>
<context>
    <name>paintScene</name>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Enter point data</source>
        <translation>Данные точки</translation>
    </message>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Data:</source>
        <translation>Данные:</translation>
    </message>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Enter some text for label...</source>
        <translation>Введите текст...</translation>
    </message>
</context>
</TS>
