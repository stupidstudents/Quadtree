<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>paint</name>
    <message>
        <location filename="../paint.ui" line="14"/>
        <source>Quad Tree (Dynamic Labels)</source>
        <translation>Quad Tree (Dynamic Labels)</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="42"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="48"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../paint.ui" line="61"/>
        <source>Load points from file...</source>
        <translation>Load points from file...</translation>
    </message>
</context>
<context>
    <name>paintScene</name>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Enter point data</source>
        <translation>Enter point data</translation>
    </message>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Data:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../paintscene.cpp" line="94"/>
        <source>Enter some text for label...</source>
        <translation>Enter some text for label...</translation>
    </message>
</context>
</TS>
